Learning Objective:
===================
Using Async Task one can run tasks that take longer than five seconds in the context of UI. The objective of the assignment is to generate sensor readings in the UI Thread context and update UI for each reading.
# Driver Page:
Please use random generate function to generate values for Temperature, Humidity and Activity Inputs.
Number of Sensor Readings value control the iteration count to generate the random values. For instance, value of 20 indicates the application will generate Output 1 to Output 20 values.

![Alt text](/MainActivity.png?raw=true "Main Activity")
